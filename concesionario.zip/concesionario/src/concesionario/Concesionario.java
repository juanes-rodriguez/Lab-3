package concesionario;
public class Concesionario {
    public static void main(String[] args) {
        
        WEBPAGE concesionario = new WEBPAGE();
        concesionario.setVisible(true);
    }
    
    
}
