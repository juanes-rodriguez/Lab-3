
package concesionario;

public class carssale {
     
    //cantCarros se va a llenar en funcion del click en el botón OK 

    
    void bubbleSortModelo(arreglos[] array)
    {
           for(int contador1=0;contador1<array.length;contador1++){
            for(int contador2=0; contador2<array.length;contador2++){
                if((contador2+1)<array.length){
                    int modeloCarro1 = (int)array[contador2].modelo;
                    int modeloCarro2 = (int)array[contador2+1].modelo;
                   
                    if(modeloCarro1>modeloCarro2){
                        arreglos temporal=array[contador2];
                        array[contador2]=array[contador2+1];
                        array[contador2+1]=temporal;
                    }
                }
            }
        }
    }
    void bubbleSortKilo(arreglos[] array)
    {
           for(int contador1=0;contador1<array.length;contador1++){
            for(int contador2=0; contador2<array.length;contador2++){
                if((contador2+1)<array.length){
                    int modeloCarro1 = (int)array[contador2].kilometraje;
                    int modeloCarro2 = (int)array[contador2+1].kilometraje;
                   
                    if(modeloCarro1>modeloCarro2){
                        arreglos temporal=array[contador2];
                        array[contador2]=array[contador2+1];
                        array[contador2+1]=temporal;
                    }
                }
            }
        }
    }

     
}
