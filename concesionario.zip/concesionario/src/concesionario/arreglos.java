
package concesionario;


public class arreglos {
   
    String color,marca;
    float kilometraje, modelo; 
    
    
    public arreglos(float fast, float model, String color, String brand ){
        this.kilometraje = fast; 
        this.modelo = model; 
        this.color = color; 
        this.marca = brand; 
    }
   
    

}
