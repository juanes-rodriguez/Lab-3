
package taller.pkg3.pkg1;


import java.util.Scanner;



public class Temporizador {
    
    public long elegirAlarma(){
        long alarma;
        Scanner read = new Scanner(System.in); 
        System.out.println("¿Cada cuanto quiere que suene la alarma?(segundos)");
        alarma = read.nextLong();
        
        return alarma; 
    }
    public int rep(){
        int rep;
        Scanner read = new Scanner(System.in); 
        System.out.println("¿Cuantas veces se repite la alarma?");
        rep = read.nextInt();
        
        return rep;
    }
   
  
    
    
    
}
