
package taller.pkg3.pkg1;

import java.util.Timer;
import java.util.Date;
import java.util.Scanner;

public class Taller31 {

   
    public static void main(String[] args) {
        System.out.println("\t\tBienvenidos al temporizador de David Rodríguez y Juan Esteban Rodriguez");
    
        Timer tempo = new Timer();
        Date fecha = new Date();
        Temporizador print = new Temporizador();
        Scanner read = new Scanner(System.in);
        Tarea run = new Tarea(); 
        
        long inicio, alarma;
        long inicioH, inicioM;

        System.out.println("\n\t¿En cuanto tiempo desea poner la alarma?\n\ta)\thoras \n\tb)\tminutos  \n\tc)\tsegundos"
        +"\n\td)\thoras,minutos, segundos \n\te)\tminutos, segundos\n");
        String incio = read.nextLine();
        switch(incio){
            case "a":
                System.out.println("¿En cuantas horas?");
                inicio = read.nextLong();
                alarma = print.elegirAlarma();
                tempo.schedule(run, inicio*3600000, alarma*1000);
                break;
                
            case "b":
                System.out.println("¿En cuantos minutos?");
                inicio = read.nextLong();
                alarma = print.elegirAlarma();
                tempo.schedule(run, inicio*60000, alarma*1000);
                break;
                
            case "c":
                System.out.println("¿En cuantos segundos?");
                inicio = read.nextLong();
                alarma = print.elegirAlarma();
                
                tempo.schedule(run, inicio*1000, alarma*1000);
                break;
                
            case "d":
                System.out.println("¿En cuantas horas?");
                inicioH = read.nextLong();
                System.out.println("¿En cuantos minutos?");
                inicioM = read.nextLong();
                System.out.println("¿En cuantos segundos?");
                inicio = read.nextLong();
                alarma = print.elegirAlarma();
                tempo.schedule(run, ((inicioH*3600000)+(inicioM*60000)+(inicio*1000)), alarma*1000);
                break;
                
            case "e":
                System.out.println("¿En cuantos minutos?");
                inicioM = read.nextLong();
                System.out.println("¿En cuantos segundos?");
                inicio = read.nextLong();
                alarma = print.elegirAlarma();
                tempo.schedule(run, ((inicioM*60000)+(inicio*1000)), alarma*1000);
        }
                    
        
    }
    
    
    
}

