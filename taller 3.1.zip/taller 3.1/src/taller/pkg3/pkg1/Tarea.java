
package taller.pkg3.pkg1;

import java.util.Date;
import java.util.TimerTask;


public class Tarea extends TimerTask {
    
    @Override
    public void run() {
        imprimirAlarma();
    } 
    public void imprimirAlarma(){
        System.out.println("Su alarma: " + new Date());
    }

    
}
